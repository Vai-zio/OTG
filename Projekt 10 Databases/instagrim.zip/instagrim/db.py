import sqlite3

from flask import current_app, g
from flask.cli import with_appcontext


def get_db():
    """ Obtain the database connection, create one if it does not exist. """
    if 'db' not in g:
        g.db = sqlite3.connect("instagrim.db")
        g.db.row_factory = sqlite3.Row
        g.db.set_trace_callback(print)
    return g.db


def close_db(e=None):
    """ Close the database connection if it is open. """
    db = g.pop('db', None)
    if db is not None:
        db.close()


def init_db():
    """ Initialize a new empty database according to schema. """
    db = get_db()
    with current_app.open_resource('schema.sql') as f:
        db.executescript(f.read().decode('utf8'))