create table if not exists users (
    'id' INTEGER primary key,
    'username' TEXT not null,
    'password' TEXT not null
);

create table if not exists posts (
    'id' INTEGER primary key,
    'userid' INTEGER,
    'msg' TEXT,
    'img' TEXT,
    'date' TEXT
);


